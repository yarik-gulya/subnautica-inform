<template>
    <div>
      <section>
        <h2>Головна сторінка</h2>
        <p>Ласкаво просимо до Subnautica Inform!</p>
        <p>Тут ви знайдете всю необхідну інформацію про гру Subnautica!</p>
      </section>
    </div>
</template>