<template>
    <MainComponent />
</template>
<script>
import MainComponent from '../components/MainComponent.vue';

export default {
  name: 'MainPage',
  components: {
    MainComponent
  }
}
</script>